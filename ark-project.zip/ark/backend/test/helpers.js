'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { loadConfig } = require('../src/config');
const { openDb } = require('../src/db');
const { createApp } = require('../src/app');
const { seedDatabase } = require('../scripts/seed');

async function startServer({ optimized = false, sizes } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ark-test-'));
  const config = loadConfig({
    dbPath: path.join(dir, 'test.db'), optimized, logLevel: 'silent', rateLimitDisabled: true,
    bcryptRounds: 4, jwtSecret: 'test-secret', staticDir: path.join(dir, 'none'),
  });
  const db = openDb(config.dbPath, { optimized });
  seedDatabase(db, { customers: 20, products: 60, orders: 120, rounds: 4,
    adminPassword: 'admin-pw', staffPassword: 'staff-pw', ...sizes });
  const { app, cache } = createApp({ db, config });
  const server = await new Promise((res) => { const s = app.listen(0, '127.0.0.1', () => res(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, url, { token, body, headers } = {}) => {
    const res = await fetch(base + url, {
      method,
      headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let json; try { json = JSON.parse(text); } catch { json = text; }
    return { status: res.status, headers: res.headers, body: json };
  };
  const login = async (u, p) => (await call('POST', '/api/auth/login', { body: { username: u, password: p } })).body.token;
  const close = async () => { await new Promise((r) => server.close(r)); db.close(); fs.rmSync(dir, { recursive: true, force: true }); };
  return { base, call, login, close, db, cache, config };
}
module.exports = { startServer };
