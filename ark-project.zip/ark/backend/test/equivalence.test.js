'use strict';
// Regression guard: the optimized implementations must return EXACTLY what the naive ones do.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer } = require('./helpers');
const orders = require('../src/services/orders');
const { computeStats } = require('../src/services/stats');

let t;
before(async () => { t = await startServer({ optimized: false, sizes: { orders: 400, customers: 30, products: 80 } }); });
after(() => t.close());

test('listOrders: naive and optimized return identical results across pages and filters', () => {
  const cases = [
    { page: 1, limit: 50 }, { page: 2, limit: 50 }, { page: 3, limit: 7 }, { page: 9, limit: 50 },
    { page: 1, limit: 100, status: 'paid' }, { page: 2, limit: 10, status: 'cancelled' },
    { page: 1, limit: 20, customerId: 5 }, { page: 1, limit: 20, customerId: 5, status: 'shipped' },
    { page: 999, limit: 50 },
  ];
  for (const q of cases) {
    assert.deepEqual(orders.listOrdersOptimized(t.db, q), orders.listOrdersNaive(t.db, q), JSON.stringify(q));
  }
});

test('indexes are added and removed with the mode, and results are unchanged', () => {
  const { applyMode } = require('../src/db');
  const q = { page: 1, limit: 25 };
  const before = orders.listOrdersNaive(t.db, q);
  const stats = computeStats(t.db);
  applyMode(t.db, true);
  const idx = () => t.db.prepare("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%'").all().length;
  assert.equal(idx(), 5);
  assert.deepEqual(orders.listOrdersOptimized(t.db, q), before);
  assert.deepEqual(computeStats(t.db), stats);
  applyMode(t.db, false);
  assert.equal(idx(), 0);
});
