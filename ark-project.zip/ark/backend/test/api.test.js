'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { startServer } = require('./helpers');

let t, admin, staff;
before(async () => {
  t = await startServer({ optimized: true });
  admin = await t.login('admin', 'admin-pw');
  staff = await t.login('staff', 'staff-pw');
});
after(() => t.close());

test('health is public and reports mode', async () => {
  const r = await t.call('GET', '/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.body.status, 'ok');
  assert.equal(r.body.mode, 'optimized');
});

test('security headers and request id are set', async () => {
  const r = await t.call('GET', '/api/health', { headers: { 'x-request-id': 'abc-123' } });
  assert.equal(r.headers.get('x-request-id'), 'abc-123');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-powered-by'), null);
  const bad = await t.call('GET', '/api/health', { headers: { 'x-request-id': 'bad id with spaces!!' } });
  assert.notEqual(bad.headers.get('x-request-id'), 'bad id with spaces!!');
});

test('auth: login failures and missing/invalid tokens', async () => {
  assert.equal((await t.call('POST', '/api/auth/login', { body: { username: 'admin', password: 'wrong' } })).status, 401);
  assert.equal((await t.call('POST', '/api/auth/login', { body: { username: 'nobody', password: 'x' } })).status, 401);
  assert.equal((await t.call('POST', '/api/auth/login', { body: {} })).status, 400);
  assert.equal((await t.call('GET', '/api/products')).status, 401);
  assert.equal((await t.call('GET', '/api/products', { token: 'garbage' })).status, 401);
});

test('authorization: staff cannot create products or read metrics, admin can', async () => {
  const payload = { sku: 'T-1', name: 'Thing', category: 'home', price_cents: 500, stock: 3 };
  assert.equal((await t.call('POST', '/api/products', { token: staff, body: payload })).status, 403);
  assert.equal((await t.call('GET', '/api/metrics', { token: staff })).status, 403);
  assert.equal((await t.call('POST', '/api/products', { token: admin, body: payload })).status, 201);
  assert.equal((await t.call('GET', '/api/metrics', { token: admin })).status, 200);
});

test('validation: bad ids, paging and JSON return 400 with the error shape', async () => {
  for (const url of ['/api/products/abc', '/api/products?page=0', '/api/products?limit=101', '/api/orders?status=bogus', '/api/orders?page=-1']) {
    const r = await t.call('GET', url, { token: admin });
    assert.equal(r.status, 400, url);
    assert.ok(r.body.error.code && r.body.error.message && r.body.error.requestId, url);
  }
  const bad = await fetch(t.base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{oops' });
  assert.equal(bad.status, 400);
  assert.equal((await t.call('GET', '/api/products/999999', { token: admin })).status, 404);
  assert.equal((await t.call('GET', '/api/nope', { token: admin })).status, 404);
});

test('products: duplicate sku conflicts; optimized mode paginates by default and caps limit', async () => {
  const payload = { sku: 'DUP-1', name: 'Dup', category: 'home', price_cents: 1, stock: 1 };
  assert.equal((await t.call('POST', '/api/products', { token: admin, body: payload })).status, 201);
  assert.equal((await t.call('POST', '/api/products', { token: admin, body: payload })).status, 409);
  const r = await t.call('GET', '/api/products', { token: admin });
  assert.equal(r.body.data.length, 20);
  assert.equal(r.body.limit, 20);
  assert.ok(r.body.total >= 60);
});

test('search treats SQL and LIKE wildcards as plain text', async () => {
  const inj = await t.call('GET', '/api/products?search=' + encodeURIComponent("x'; DROP TABLE products;--"), { token: admin });
  assert.equal(inj.status, 200);
  assert.equal(inj.body.total, 0);
  const pct = await t.call('GET', '/api/products?search=%25', { token: admin });
  assert.equal(pct.body.total, 0); // "%" is literal, not "match everything"
  assert.ok((await t.call('GET', '/api/products', { token: admin })).body.total > 0);
});

function firstProductWithStock() {
  return t.db.prepare('SELECT id, stock FROM products WHERE stock >= 5 ORDER BY id LIMIT 1').get();
}

test('orders: create decrements stock and totals correctly', async () => {
  const p = firstProductWithStock();
  const price = t.db.prepare('SELECT price_cents FROM products WHERE id = ?').get(p.id).price_cents;
  const r = await t.call('POST', '/api/orders', { token: staff, body: { customer_id: 1, items: [{ product_id: p.id, quantity: 2 }] } });
  assert.equal(r.status, 201);
  assert.equal(r.body.total_cents, price * 2);
  assert.equal(r.body.status, 'pending');
  assert.equal(t.db.prepare('SELECT stock FROM products WHERE id = ?').get(p.id).stock, p.stock - 2);
});

test('orders: insufficient stock rolls back everything (no partial stock changes)', async () => {
  const [a, b] = t.db.prepare('SELECT id, stock FROM products WHERE stock >= 3 ORDER BY id LIMIT 2').all();
  const before = t.db.prepare('SELECT COUNT(*) n FROM orders').get().n;
  const r = await t.call('POST', '/api/orders', { token: staff, body: { customer_id: 1, items: [
    { product_id: a.id, quantity: 1 }, { product_id: b.id, quantity: b.stock + 1 }] } });
  assert.equal(r.status, 409);
  assert.equal(t.db.prepare('SELECT stock FROM products WHERE id = ?').get(a.id).stock, a.stock);
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM orders').get().n, before);
});

test('orders: rejects bad bodies (empty, duplicate product, zero quantity, unknown customer)', async () => {
  const p = firstProductWithStock();
  const cases = [
    { customer_id: 1, items: [] },
    { customer_id: 1, items: [{ product_id: p.id, quantity: 1 }, { product_id: p.id, quantity: 1 }] },
    { customer_id: 1, items: [{ product_id: p.id, quantity: 0 }] },
    { customer_id: 999999, items: [{ product_id: p.id, quantity: 1 }] },
  ];
  for (const body of cases) assert.equal((await t.call('POST', '/api/orders', { token: staff, body })).status, 400, JSON.stringify(body));
});

test('orders: status transitions are enforced and cancelling restocks', async () => {
  const p = firstProductWithStock();
  const created = await t.call('POST', '/api/orders', { token: staff, body: { customer_id: 2, items: [{ product_id: p.id, quantity: 2 }] } });
  const id = created.body.id;
  const stockAfterCreate = t.db.prepare('SELECT stock FROM products WHERE id = ?').get(p.id).stock;
  assert.equal((await t.call('PATCH', `/api/orders/${id}/status`, { token: staff, body: { status: 'shipped' } })).status, 409); // pending -> shipped not allowed
  assert.equal((await t.call('PATCH', `/api/orders/${id}/status`, { token: staff, body: { status: 'cancelled' } })).status, 200);
  assert.equal(t.db.prepare('SELECT stock FROM products WHERE id = ?').get(p.id).stock, stockAfterCreate + 2);
  assert.equal((await t.call('PATCH', `/api/orders/${id}/status`, { token: staff, body: { status: 'paid' } })).status, 409); // cancelled is final
});

test('stats cache: second call hits cache; writes invalidate it', async () => {
  t.cache.invalidate();
  const h0 = t.cache.stats().hits;
  await t.call('GET', '/api/stats', { token: admin });
  await t.call('GET', '/api/stats', { token: admin });
  assert.equal(t.cache.stats().hits, h0 + 1);
  const before = (await t.call('GET', '/api/stats', { token: admin })).body;
  const p = firstProductWithStock();
  await t.call('POST', '/api/orders', { token: staff, body: { customer_id: 3, items: [{ product_id: p.id, quantity: 1 }] } });
  const after = (await t.call('GET', '/api/stats', { token: admin })).body;
  const sum = (s) => s.byStatus.reduce((n, x) => n + x.orders, 0);
  assert.equal(sum(after), sum(before) + 1);
});
