'use strict';
class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
const badRequest = (m) => new HttpError(400, 'BAD_REQUEST', m);
const unauthorized = (m = 'Authentication required') => new HttpError(401, 'UNAUTHORIZED', m);
const forbidden = (m = 'Not allowed') => new HttpError(403, 'FORBIDDEN', m);
const notFound = (m = 'Not found') => new HttpError(404, 'NOT_FOUND', m);
const conflict = (m) => new HttpError(409, 'CONFLICT', m);
module.exports = { HttpError, badRequest, unauthorized, forbidden, notFound, conflict };
