'use strict';
// Process-local TTL cache. Fine for ONE instance. With several instances each has
// its own copy, so data can be stale up to TTL on any instance; use Redis only if that matters.
class Cache {
  constructor() {
    this.map = new Map();
    this.hits = 0;
    this.misses = 0;
  }
  getOrCompute(key, ttlMs, fn) {
    const e = this.map.get(key);
    const now = Date.now();
    if (e && e.expires > now) {
      this.hits++;
      return e.value;
    }
    this.misses++;
    const value = fn();
    this.map.set(key, { value, expires: now + ttlMs });
    return value;
  }
  invalidate(key) {
    if (key === undefined) this.map.clear();
    else this.map.delete(key);
  }
  stats() {
    const total = this.hits + this.misses;
    return { hits: this.hits, misses: this.misses, hitRate: total ? this.hits / total : 0, size: this.map.size };
  }
}
module.exports = { Cache };
