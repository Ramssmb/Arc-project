'use strict';
const path = require('path');

function loadConfig(overrides = {}) {
  const env = process.env;
  const cfg = {
    env: env.NODE_ENV || 'development',
    port: Number(env.PORT || 3000),
    dbPath: env.DB_PATH || path.join(__dirname, '..', 'data', 'ark.db'),
    jwtSecret: env.JWT_SECRET || '',
    jwtTtl: env.JWT_TTL || '1h',
    // OPTIMIZED=1 turns on indexes, pagination defaults, batched queries and caching.
    // It exists so baseline vs optimized can be measured on the same code and data.
    optimized: env.OPTIMIZED === '1',
    cacheTtlMs: Number(env.CACHE_TTL_MS || 30000),
    bcryptRounds: Number(env.BCRYPT_ROUNDS || 10),
    rateLimitDisabled: env.RATE_LIMIT_DISABLED === '1',
    logLevel: env.LOG_LEVEL || 'info',
    staticDir: env.STATIC_DIR || path.join(__dirname, '..', '..', 'frontend', 'dist'),
    ...overrides,
  };
  if (!cfg.jwtSecret) {
    if (cfg.env === 'production') {
      throw new Error('JWT_SECRET must be set in production');
    }
    cfg.jwtSecret = 'dev-only-insecure-secret';
  }
  return cfg;
}
module.exports = { loadConfig };
