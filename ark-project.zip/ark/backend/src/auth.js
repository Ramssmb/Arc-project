'use strict';
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { unauthorized, forbidden } = require('./errors');

// Used to keep login timing similar whether or not the user exists.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 4);

function makeAuth(config) {
  const sign = (user) =>
    jwt.sign({ sub: user.id, role: user.role, name: user.username }, config.jwtSecret,
      { expiresIn: config.jwtTtl, algorithm: 'HS256' });

  const authenticate = (req, _res, next) => {
    const h = req.headers.authorization || '';
    const m = /^Bearer (.+)$/.exec(h);
    if (!m) return next(unauthorized());
    try {
      const p = jwt.verify(m[1], config.jwtSecret, { algorithms: ['HS256'] });
      req.user = { id: p.sub, role: p.role, username: p.name };
      return next();
    } catch {
      return next(unauthorized('Invalid or expired token'));
    }
  };

  const requireRole = (...roles) => (req, _res, next) =>
    roles.includes(req.user.role) ? next() : next(forbidden('Insufficient role'));

  const verifyLogin = (db, username, password) => {
    const u = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    const ok = bcrypt.compareSync(password, u ? u.password_hash : DUMMY_HASH);
    return u && ok ? u : null;
  };

  return { sign, authenticate, requireRole, verifyLogin };
}
module.exports = { makeAuth };
