'use strict';
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 99 };
function createLogger(level = 'info') {
  const min = LEVELS[level] ?? 20;
  const log = (lvl, msg, extra) => {
    if (LEVELS[lvl] < min) return;
    // Never pass bodies, tokens or passwords into extra.
    process.stdout.write(JSON.stringify({ ts: new Date().toISOString(), level: lvl, msg, ...extra }) + '\n');
  };
  return {
    debug: (m, e) => log('debug', m, e),
    info: (m, e) => log('info', m, e),
    warn: (m, e) => log('warn', m, e),
    error: (m, e) => log('error', m, e),
  };
}
module.exports = { createLogger };
