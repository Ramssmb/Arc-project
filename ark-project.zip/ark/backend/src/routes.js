'use strict';
const express = require('express');
const rateLimit = require('express-rate-limit');
const { int, str, oneOf } = require('./validate');
const { badRequest, unauthorized } = require('./errors');
const products = require('./services/products');
const orders = require('./services/orders');
const { computeStats } = require('./services/stats');

const STATS_KEY = 'stats';

function buildRoutes({ db, config, cache, metrics, auth }) {
  const r = express.Router();
  const wrap = (fn) => (req, res, next) => {
    try { fn(req, res, next); } catch (e) { next(e); }
  };
  const anyUser = [auth.authenticate];
  const adminOnly = [auth.authenticate, auth.requireRole('admin')];
  const staffOrAdmin = [auth.authenticate, auth.requireRole('admin', 'staff')];

  const loginLimiter = rateLimit({
    windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false,
    skip: () => config.rateLimitDisabled,
    handler: (_req, _res, next) => next(Object.assign(new Error('Too many login attempts'), { status: 429, code: 'RATE_LIMITED' })),
  });

  r.get('/health', wrap((_req, res) => {
    db.prepare('SELECT 1').get();
    res.json({ status: 'ok', mode: config.optimized ? 'optimized' : 'baseline' });
  }));

  r.post('/auth/login', loginLimiter, wrap((req, res) => {
    const body = req.body || {};
    const username = str(body.username, 'username', { max: 64 });
    const password = str(body.password, 'password', { max: 200 });
    const user = auth.verifyLogin(db, username, password);
    if (!user) throw unauthorized('Invalid username or password');
    res.json({ token: auth.sign(user), user: { id: user.id, username: user.username, role: user.role } });
  }));

  r.get('/metrics', ...adminOnly, wrap((_req, res) => {
    res.json({ ...metrics.snapshot(), cache: cache.stats(), mode: config.optimized ? 'optimized' : 'baseline' });
  }));

  // ---- products ----
  r.get('/products', ...anyUser, wrap((req, res) => {
    const q = req.query;
    const search = str(q.search, 'search', { max: 100, optional: true });
    const category = str(q.category, 'category', { max: 50, optional: true });
    const page = int(q.page, 'page', { min: 1, max: 1_000_000, def: 1 });
    // Baseline returns everything unless a limit is given. Optimized defaults to 20 and caps at 100.
    const limit = config.optimized
      ? int(q.limit, 'limit', { min: 1, max: 100, def: 20 })
      : (q.limit === undefined ? null : int(q.limit, 'limit', { min: 1, max: 100000 }));
    res.json(products.listProducts(db, { search, category, page, limit }));
  }));

  r.get('/products/:id', ...anyUser, wrap((req, res) => {
    res.json(products.getProduct(db, int(req.params.id, 'id', { min: 1 })));
  }));

  const productBody = (b = {}) => ({
    name: str(b.name, 'name', { max: 200 }),
    category: str(b.category, 'category', { max: 50 }),
    priceCents: int(b.price_cents, 'price_cents', { min: 0, max: 100_000_000 }),
    stock: int(b.stock, 'stock', { min: 0, max: 1_000_000 }),
  });

  r.post('/products', ...adminOnly, wrap((req, res) => {
    const b = req.body || {};
    const created = products.createProduct(db, { sku: str(b.sku, 'sku', { max: 64 }), ...productBody(b) });
    cache.invalidate(STATS_KEY);
    res.status(201).json(created);
  }));

  r.put('/products/:id', ...adminOnly, wrap((req, res) => {
    const out = products.updateProduct(db, int(req.params.id, 'id', { min: 1 }), productBody(req.body));
    cache.invalidate(STATS_KEY);
    res.json(out);
  }));

  // ---- orders ----
  r.get('/orders', ...anyUser, wrap((req, res) => {
    const q = req.query;
    const query = {
      page: int(q.page, 'page', { min: 1, max: 1_000_000, def: 1 }),
      limit: int(q.limit, 'limit', { min: 1, max: 100, def: 50 }),
      status: oneOf(q.status, 'status', orders.STATUSES, { optional: true }),
      customerId: q.customer_id === undefined ? undefined : int(q.customer_id, 'customer_id', { min: 1 }),
    };
    res.json(config.optimized ? orders.listOrdersOptimized(db, query) : orders.listOrdersNaive(db, query));
  }));

  r.get('/orders/:id', ...anyUser, wrap((req, res) => {
    res.json(orders.getOrder(db, int(req.params.id, 'id', { min: 1 })));
  }));

  r.post('/orders', ...staffOrAdmin, wrap((req, res) => {
    const b = req.body || {};
    const customerId = int(b.customer_id, 'customer_id', { min: 1 });
    if (!Array.isArray(b.items) || b.items.length < 1 || b.items.length > 50) {
      throw badRequest('items must be an array of 1-50 entries');
    }
    const seen = new Set();
    const items = b.items.map((it, i) => {
      const productId = int(it && it.product_id, `items[${i}].product_id`, { min: 1 });
      const quantity = int(it && it.quantity, `items[${i}].quantity`, { min: 1, max: 1000 });
      if (seen.has(productId)) throw badRequest(`duplicate product_id ${productId}`);
      seen.add(productId);
      return { productId, quantity };
    });
    const created = orders.createOrder(db, { customerId, items });
    cache.invalidate(STATS_KEY);
    res.status(201).json(created);
  }));

  r.patch('/orders/:id/status', ...staffOrAdmin, wrap((req, res) => {
    const next = oneOf((req.body || {}).status, 'status', orders.STATUSES);
    const out = orders.updateStatus(db, int(req.params.id, 'id', { min: 1 }), next);
    cache.invalidate(STATS_KEY);
    res.json(out);
  }));

  // ---- stats ----
  r.get('/stats', ...anyUser, wrap((_req, res) => {
    res.json(config.optimized
      ? cache.getOrCompute(STATS_KEY, config.cacheTtlMs, () => computeStats(db))
      : computeStats(db));
  }));

  return r;
}
module.exports = { buildRoutes };
