'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const { buildRoutes } = require('./routes');
const { Cache } = require('./cache');
const { Metrics } = require('./metrics');
const { makeAuth } = require('./auth');
const { createLogger } = require('./logger');
const { HttpError } = require('./errors');

function createApp({ db, config }) {
  const logger = createLogger(config.logLevel);
  const cache = new Cache();
  const metrics = new Metrics();
  const auth = makeAuth(config);
  const app = express();

  app.disable('x-powered-by');
  app.use(helmet());
  app.use(express.json({ limit: '100kb' }));

  // Request id + structured access log (method, path without query string, status, duration only).
  app.use((req, res, next) => {
    const incoming = req.headers['x-request-id'];
    req.id = typeof incoming === 'string' && /^[\w-]{1,64}$/.test(incoming) ? incoming : crypto.randomUUID();
    res.setHeader('x-request-id', req.id);
    const t0 = process.hrtime.bigint();
    res.on('finish', () => {
      const ms = Number(process.hrtime.bigint() - t0) / 1e6;
      const route = req.route ? req.baseUrl + req.route.path : 'unmatched';
      metrics.record(`${req.method} ${route}`, res.statusCode, ms);
      logger.info('request', { id: req.id, method: req.method, path: req.originalUrl.split('?')[0],
        status: res.statusCode, ms: +ms.toFixed(2) });
    });
    next();
  });

  app.use('/api', buildRoutes({ db, config, cache, metrics, auth }));

  if (fs.existsSync(path.join(config.staticDir, 'index.html'))) {
    app.use(express.static(config.staticDir));
    app.get(/^\/(?!api\/).*/, (_req, res) => res.sendFile(path.join(config.staticDir, 'index.html')));
  }

  app.use('/api', (req, _res, next) => next(new HttpError(404, 'NOT_FOUND', 'Route not found')));

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, _next) => {
    let status = err.status || 500;
    let code = err.code || 'INTERNAL';
    let message = err.message;
    if (err.type === 'entity.parse.failed') { status = 400; code = 'BAD_REQUEST'; message = 'Invalid JSON body'; }
    if (err.type === 'entity.too.large') { status = 413; code = 'TOO_LARGE'; message = 'Body too large'; }
    if (status >= 500) {
      logger.error('unhandled', { id: req.id, error: err.message, stack: err.stack });
      message = 'Internal server error'; // never leak internals
      code = 'INTERNAL';
    }
    res.status(status).json({ error: { code, message, requestId: req.id } });
  });

  return { app, cache, metrics, logger };
}
module.exports = { createApp };
