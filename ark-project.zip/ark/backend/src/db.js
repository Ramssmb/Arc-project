'use strict';
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','staff'))
);
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY,
  sku TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
  stock INTEGER NOT NULL CHECK (stock >= 0),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  status TEXT NOT NULL CHECK (status IN ('pending','paid','shipped','cancelled')),
  total_cents INTEGER NOT NULL CHECK (total_cents >= 0),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents >= 0)
);
`;

// Added only in optimized mode; dropped in baseline mode so the toggle is reversible.
const OPT_INDEXES = {
  idx_orders_created: 'orders(created_at DESC, id DESC)',
  idx_orders_status_created: 'orders(status, created_at DESC, id DESC)',
  idx_orders_customer_created: 'orders(customer_id, created_at DESC, id DESC)',
  idx_items_order: 'order_items(order_id)',
  idx_items_product_qty: 'order_items(product_id, quantity)',
};

function applyMode(db, optimized) {
  for (const [name, def] of Object.entries(OPT_INDEXES)) {
    if (optimized) db.exec(`CREATE INDEX IF NOT EXISTS ${name} ON ${def}`);
    else db.exec(`DROP INDEX IF EXISTS ${name}`);
  }
  if (optimized) db.exec('ANALYZE');
}

function openDb(dbPath, { optimized = false } = {}) {
  if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');
  db.exec(SCHEMA);
  applyMode(db, optimized);
  return db;
}

module.exports = { openDb, applyMode, OPT_INDEXES };
