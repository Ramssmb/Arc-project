'use strict';
const { loadConfig } = require('./config');
const { openDb } = require('./db');
const { createApp } = require('./app');

const config = loadConfig();
const db = openDb(config.dbPath, { optimized: config.optimized });
const { app, logger } = createApp({ db, config });

const server = app.listen(config.port, () => {
  logger.info('listening', { port: config.port, mode: config.optimized ? 'optimized' : 'baseline', env: config.env });
});

function shutdown(signal) {
  logger.info('shutting down', { signal });
  server.close(() => { db.close(); process.exit(0); });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
