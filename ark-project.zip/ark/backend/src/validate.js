'use strict';
const { badRequest } = require('./errors');

function int(value, name, { min = -Infinity, max = Infinity, def } = {}) {
  if (value === undefined || value === null || value === '') {
    if (def !== undefined) return def;
    throw badRequest(`${name} is required`);
  }
  const s = String(value);
  if (!/^-?\d+$/.test(s)) throw badRequest(`${name} must be an integer`);
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < min || n > max) {
    throw badRequest(`${name} must be between ${min} and ${max}`);
  }
  return n;
}

function str(value, name, { min = 1, max = 200, optional = false } = {}) {
  if (value === undefined || value === null || value === '') {
    if (optional) return undefined;
    throw badRequest(`${name} is required`);
  }
  if (typeof value !== 'string') throw badRequest(`${name} must be a string`);
  const t = value.trim();
  if (t.length < min || t.length > max) throw badRequest(`${name} must be ${min}-${max} characters`);
  return t;
}

function oneOf(value, name, allowed, { optional = false } = {}) {
  if (value === undefined || value === '') {
    if (optional) return undefined;
    throw badRequest(`${name} is required`);
  }
  if (!allowed.includes(value)) throw badRequest(`${name} must be one of: ${allowed.join(', ')}`);
  return value;
}

module.exports = { int, str, oneOf };
