'use strict';
class Metrics {
  constructor() {
    this.startedAt = Date.now();
    this.routes = new Map();
  }
  record(route, status, ms) {
    let r = this.routes.get(route);
    if (!r) {
      r = { count: 0, errors5xx: 0, errors4xx: 0, totalMs: 0, maxMs: 0 };
      this.routes.set(route, r);
    }
    r.count++;
    r.totalMs += ms;
    if (ms > r.maxMs) r.maxMs = ms;
    if (status >= 500) r.errors5xx++;
    else if (status >= 400) r.errors4xx++;
  }
  snapshot() {
    const routes = {};
    for (const [k, v] of this.routes) {
      routes[k] = { ...v, avgMs: v.count ? +(v.totalMs / v.count).toFixed(2) : 0, totalMs: undefined };
    }
    const mem = process.memoryUsage();
    return {
      uptimeSec: Math.round((Date.now() - this.startedAt) / 1000),
      rssMb: Math.round(mem.rss / 1048576),
      heapUsedMb: Math.round(mem.heapUsed / 1048576),
      routes,
    };
  }
}
module.exports = { Metrics };
