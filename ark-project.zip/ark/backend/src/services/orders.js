'use strict';
const { badRequest, notFound, conflict } = require('../errors');

const STATUSES = ['pending', 'paid', 'shipped', 'cancelled'];
const TRANSITIONS = { pending: ['paid', 'cancelled'], paid: ['shipped', 'cancelled'], shipped: [], cancelled: [] };

const ITEM_COLS = `oi.id, oi.order_id, oi.product_id, p.name AS product_name, oi.quantity, oi.unit_price_cents`;

function buildFilter({ status, customerId }) {
  const where = [];
  const params = [];
  if (status) { where.push('o.status = ?'); params.push(status); }
  if (customerId) { where.push('o.customer_id = ?'); params.push(customerId); }
  return { sql: where.length ? ` WHERE ${where.join(' AND ')}` : '', params };
}

const shape = (o, customer, items) => ({
  id: o.id,
  status: o.status,
  total_cents: o.total_cents,
  created_at: o.created_at,
  customer: { id: customer.id, name: customer.name, email: customer.email },
  items: items.map((i) => ({
    product_id: i.product_id,
    product_name: i.product_name,
    quantity: i.quantity,
    unit_price_cents: i.unit_price_cents,
  })),
});

function count(db, f) {
  return db.prepare(`SELECT COUNT(*) AS n FROM orders o${f.sql}`).get(...f.params).n;
}

// BASELINE: deliberately naive. 1 query for the page + 2 queries per order (N+1).
function listOrdersNaive(db, q) {
  const f = buildFilter(q);
  const rows = db
    .prepare(`SELECT o.id, o.customer_id, o.status, o.total_cents, o.created_at FROM orders o${f.sql}
              ORDER BY o.created_at DESC, o.id DESC LIMIT ? OFFSET ?`)
    .all(...f.params, q.limit, (q.page - 1) * q.limit);
  const data = rows.map((r) => {
    const customer = db.prepare('SELECT id, name, email FROM customers WHERE id = ?').get(r.customer_id);
    const items = db
      .prepare(`SELECT ${ITEM_COLS} FROM order_items oi JOIN products p ON p.id = oi.product_id
                WHERE oi.order_id = ? ORDER BY oi.id`)
      .all(r.id);
    return shape(r, customer, items);
  });
  return { data, page: q.page, limit: q.limit, total: count(db, f) };
}

// OPTIMIZED: 3 queries per page regardless of page size. Same output as the naive version.
function listOrdersOptimized(db, q) {
  const f = buildFilter(q);
  const rows = db
    .prepare(`SELECT o.id, o.status, o.total_cents, o.created_at,
                     c.id AS c_id, c.name AS c_name, c.email AS c_email
              FROM orders o JOIN customers c ON c.id = o.customer_id${f.sql}
              ORDER BY o.created_at DESC, o.id DESC LIMIT ? OFFSET ?`)
    .all(...f.params, q.limit, (q.page - 1) * q.limit);
  const byOrder = new Map();
  if (rows.length) {
    const ids = rows.map((r) => r.id);
    const marks = ids.map(() => '?').join(',');
    const items = db
      .prepare(`SELECT ${ITEM_COLS} FROM order_items oi JOIN products p ON p.id = oi.product_id
                WHERE oi.order_id IN (${marks}) ORDER BY oi.id`)
      .all(...ids);
    for (const it of items) {
      if (!byOrder.has(it.order_id)) byOrder.set(it.order_id, []);
      byOrder.get(it.order_id).push(it);
    }
  }
  const data = rows.map((r) =>
    shape(r, { id: r.c_id, name: r.c_name, email: r.c_email }, byOrder.get(r.id) || []));
  return { data, page: q.page, limit: q.limit, total: count(db, f) };
}

function getOrder(db, id) {
  const o = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
  if (!o) throw notFound('Order not found');
  const customer = db.prepare('SELECT id, name, email FROM customers WHERE id = ?').get(o.customer_id);
  const items = db
    .prepare(`SELECT ${ITEM_COLS} FROM order_items oi JOIN products p ON p.id = oi.product_id
              WHERE oi.order_id = ? ORDER BY oi.id`)
    .all(id);
  return shape(o, customer, items);
}

function createOrder(db, { customerId, items }) {
  const tx = db.transaction(() => {
    const customer = db.prepare('SELECT id FROM customers WHERE id = ?').get(customerId);
    if (!customer) throw badRequest('customer_id does not exist');
    let total = 0;
    const lines = [];
    for (const it of items) {
      const p = db.prepare('SELECT id, name, price_cents, stock FROM products WHERE id = ?').get(it.productId);
      if (!p) throw badRequest(`product ${it.productId} does not exist`);
      if (p.stock < it.quantity) throw conflict(`insufficient stock for product ${p.id}`);
      db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(it.quantity, p.id);
      total += p.price_cents * it.quantity;
      lines.push({ productId: p.id, quantity: it.quantity, price: p.price_cents });
    }
    const now = new Date().toISOString();
    const { lastInsertRowid } = db
      .prepare('INSERT INTO orders (customer_id, status, total_cents, created_at) VALUES (?, ?, ?, ?)')
      .run(customerId, 'pending', total, now);
    const ins = db.prepare(
      'INSERT INTO order_items (order_id, product_id, quantity, unit_price_cents) VALUES (?, ?, ?, ?)');
    for (const l of lines) ins.run(lastInsertRowid, l.productId, l.quantity, l.price);
    return Number(lastInsertRowid);
  });
  return getOrder(db, tx());
}

function updateStatus(db, id, next) {
  const tx = db.transaction(() => {
    const o = db.prepare('SELECT id, status FROM orders WHERE id = ?').get(id);
    if (!o) throw notFound('Order not found');
    if (!TRANSITIONS[o.status].includes(next)) {
      throw conflict(`cannot change order from ${o.status} to ${next}`);
    }
    if (next === 'cancelled') {
      const items = db.prepare('SELECT product_id, quantity FROM order_items WHERE order_id = ?').all(id);
      for (const it of items) {
        db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(it.quantity, it.product_id);
      }
    }
    db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(next, id);
  });
  tx();
  return getOrder(db, id);
}

module.exports = { STATUSES, listOrdersNaive, listOrdersOptimized, getOrder, createOrder, updateStatus };
