'use strict';
function computeStats(db) {
  const byStatus = db
    .prepare(`SELECT status, COUNT(*) AS orders, COALESCE(SUM(total_cents),0) AS revenue_cents
              FROM orders GROUP BY status ORDER BY status`).all();
  const topProducts = db
    .prepare(`SELECT p.id, p.name, SUM(oi.quantity) AS units
              FROM order_items oi JOIN products p ON p.id = oi.product_id
              GROUP BY p.id ORDER BY units DESC, p.id ASC LIMIT 10`).all();
  const lowStock = db.prepare('SELECT COUNT(*) AS n FROM products WHERE stock < 10').get().n;
  return { byStatus, topProducts, lowStockProducts: lowStock };
}
module.exports = { computeStats };
