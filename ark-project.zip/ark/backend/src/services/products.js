'use strict';
const { notFound, conflict } = require('../errors');

const COLS = 'id, sku, name, category, price_cents, stock';

// LIKE wildcards in user input are escaped so "%" searches for a literal percent sign.
const likeEscape = (s) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

function listProducts(db, { search, category, page, limit }) {
  const where = [];
  const params = [];
  if (search) { where.push("name LIKE ? ESCAPE '\\'"); params.push(`%${likeEscape(search)}%`); }
  if (category) { where.push('category = ?'); params.push(category); }
  const sql = where.length ? ` WHERE ${where.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM products${sql}`).get(...params).n;
  // limit === null means "no limit" (baseline behaviour).
  const rows = limit === null
    ? db.prepare(`SELECT ${COLS} FROM products${sql} ORDER BY id`).all(...params)
    : db.prepare(`SELECT ${COLS} FROM products${sql} ORDER BY id LIMIT ? OFFSET ?`)
        .all(...params, limit, (page - 1) * limit);
  return { data: rows, page, limit: limit === null ? total : limit, total };
}

function getProduct(db, id) {
  const p = db.prepare(`SELECT ${COLS} FROM products WHERE id = ?`).get(id);
  if (!p) throw notFound('Product not found');
  return p;
}

function createProduct(db, { sku, name, category, priceCents, stock }) {
  try {
    const r = db
      .prepare('INSERT INTO products (sku, name, category, price_cents, stock, created_at) VALUES (?,?,?,?,?,?)')
      .run(sku, name, category, priceCents, stock, new Date().toISOString());
    return getProduct(db, Number(r.lastInsertRowid));
  } catch (e) {
    if (String(e.code).startsWith('SQLITE_CONSTRAINT')) throw conflict('sku already exists');
    throw e;
  }
}

function updateProduct(db, id, { name, category, priceCents, stock }) {
  getProduct(db, id);
  db.prepare('UPDATE products SET name = ?, category = ?, price_cents = ?, stock = ? WHERE id = ?')
    .run(name, category, priceCents, stock, id);
  return getProduct(db, id);
}

module.exports = { listProducts, getProduct, createProduct, updateProduct };
