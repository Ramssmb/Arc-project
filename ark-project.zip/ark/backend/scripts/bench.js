'use strict';
// Closed-loop load generator with exact percentiles. Usage:
//   BASE_URL=http://localhost:3000 DURATION_S=15 CONCURRENCY=20 node scripts/bench.js
// Local runs share CPU with the server: compare relative before/after, not absolute capacity.
const SCENARIOS = [
  { name: 'GET /orders (page)', weight: 4, req: (r) => `/api/orders?page=${1 + Math.floor(r() * 50)}` },
  { name: 'GET /products?search', weight: 3, req: (r) => `/api/products?search=${['Lantern', 'Kettle', 'Steel', 'Amber', 'Quiet'][Math.floor(r() * 5)]}&limit=20` },
  { name: 'GET /products/:id', weight: 3, req: (r) => `/api/products/${1 + Math.floor(r() * 5000)}` },
  { name: 'GET /stats', weight: 2, req: () => '/api/stats' },
  { name: 'GET /orders (by customer)', weight: 2, req: (r) => `/api/orders?customer_id=${1 + Math.floor(r() * 2000)}&limit=20` },
];

const pct = (sorted, p) => (sorted.length ? sorted[Math.min(sorted.length - 1, Math.ceil((p / 100) * sorted.length) - 1)] : 0);

async function login(base) {
  const res = await fetch(`${base}/api/auth/login`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: process.env.ARK_ADMIN_PASSWORD || 'admin-change-me' }),
  });
  if (!res.ok) throw new Error(`login failed: ${res.status}`);
  return (await res.json()).token;
}

async function run({ base, durationS = 15, concurrency = 20, warmupS = 2 }) {
  const token = await login(base);
  const bag = SCENARIOS.flatMap((s) => Array(s.weight).fill(s));
  const stats = new Map(SCENARIOS.map((s) => [s.name, { lat: [], errors: 0 }]));
  let measuring = false;
  const t0 = Date.now();
  const endAt = t0 + (warmupS + durationS) * 1000;
  const measureFrom = t0 + warmupS * 1000;
  let seed = 1234;
  const r = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

  async function worker() {
    while (Date.now() < endAt) {
      const sc = bag[Math.floor(r() * bag.length)];
      const s = performance.now();
      let ok = false;
      try {
        const res = await fetch(base + sc.req(r), { headers: { authorization: `Bearer ${token}` } });
        await res.arrayBuffer();
        ok = res.status === 200;
      } catch { ok = false; }
      const ms = performance.now() - s;
      if (Date.now() >= measureFrom) {
        const st = stats.get(sc.name);
        st.lat.push(ms);
        if (!ok) st.errors++;
      }
    }
  }
  await Promise.all(Array.from({ length: concurrency }, worker));

  const rows = [];
  let all = [];
  let allErr = 0;
  for (const [name, st] of stats) {
    const l = st.lat.sort((a, b) => a - b);
    all = all.concat(l);
    allErr += st.errors;
    rows.push({ name, count: l.length, errors: st.errors, p50: pct(l, 50), p95: pct(l, 95), p99: pct(l, 99),
      avg: l.length ? l.reduce((a, b) => a + b, 0) / l.length : 0 });
  }
  all.sort((a, b) => a - b);
  const overall = { count: all.length, errors: allErr, rps: all.length / durationS,
    p50: pct(all, 50), p95: pct(all, 95), p99: pct(all, 99) };
  return { rows, overall, config: { durationS, concurrency, warmupS } };
}

const fmt = (n) => n.toFixed(1);
function toMarkdown(label, res) {
  const lines = [`### ${label}`, `concurrency=${res.config.concurrency}, duration=${res.config.durationS}s (+${res.config.warmupS}s warmup)`, '',
    '| Scenario | Requests | Errors | p50 ms | p95 ms | p99 ms |', '|---|---|---|---|---|---|'];
  for (const x of res.rows) lines.push(`| ${x.name} | ${x.count} | ${x.errors} | ${fmt(x.p50)} | ${fmt(x.p95)} | ${fmt(x.p99)} |`);
  const o = res.overall;
  lines.push(`| **overall** | ${o.count} | ${o.errors} | ${fmt(o.p50)} | ${fmt(o.p95)} | ${fmt(o.p99)} |`, '', `Throughput: ${o.rps.toFixed(0)} req/s`);
  return lines.join('\n');
}

module.exports = { run, toMarkdown };

if (require.main === module) {
  run({ base: process.env.BASE_URL || 'http://localhost:3000',
    durationS: Number(process.env.DURATION_S || 15), concurrency: Number(process.env.CONCURRENCY || 20) })
    .then((res) => console.log(toMarkdown('Benchmark', res)))
    .catch((e) => { console.error(e.message); process.exit(1); });
}
