'use strict';
// Deterministic seed data. Usage: node scripts/seed.js [--reset]
const fs = require('fs');
const bcrypt = require('bcryptjs');
const { loadConfig } = require('../src/config');
const { openDb } = require('../src/db');

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const ADJ = ['Compact', 'Heavy', 'Studio', 'Field', 'Rapid', 'Quiet', 'Steel', 'Linen', 'Solar', 'Amber'];
const NOUN = ['Lantern', 'Kettle', 'Backpack', 'Notebook', 'Speaker', 'Jacket', 'Bottle', 'Tripod', 'Blender', 'Helmet'];
const CATS = ['home', 'outdoor', 'office', 'audio', 'kitchen', 'apparel', 'travel', 'fitness'];
const FIRST = ['Asha', 'Ravi', 'Meera', 'Kabir', 'Isha', 'Dev', 'Nina', 'Omar', 'Lena', 'Arjun'];
const LAST = ['Sharma', 'Verma', 'Khan', 'Singh', 'Gill', 'Mehta', 'Rao', 'Das', 'Kaur', 'Bose'];

function seedDatabase(db, { customers = 2000, products = 5000, orders = 50000, rounds = 10,
  adminPassword = 'admin-change-me', staffPassword = 'staff-change-me', seed = 42 } = {}) {
  const rand = rng(seed);
  const pick = (a) => a[Math.floor(rand() * a.length)];
  const between = (lo, hi) => lo + Math.floor(rand() * (hi - lo + 1));

  db.transaction(() => {
    const u = db.prepare('INSERT INTO users (username, password_hash, role) VALUES (?,?,?)');
    u.run('admin', bcrypt.hashSync(adminPassword, rounds), 'admin');
    u.run('staff', bcrypt.hashSync(staffPassword, rounds), 'staff');

    const base = Date.parse('2024-01-01T00:00:00Z');
    const span = 2 * 365 * 24 * 3600 * 1000;
    const iso = (ms) => new Date(ms).toISOString();

    const c = db.prepare('INSERT INTO customers (name, email, created_at) VALUES (?,?,?)');
    for (let i = 1; i <= customers; i++) {
      c.run(`${pick(FIRST)} ${pick(LAST)}`, `customer${i}@example.test`, iso(base + Math.floor(rand() * span)));
    }
    const p = db.prepare('INSERT INTO products (sku, name, category, price_cents, stock, created_at) VALUES (?,?,?,?,?,?)');
    const prices = [];
    for (let i = 1; i <= products; i++) {
      const price = between(199, 99999);
      prices.push(price);
      p.run(`SKU-${String(i).padStart(6, '0')}`, `${pick(ADJ)} ${pick(NOUN)} ${i}`, pick(CATS),
        price, between(0, 500), iso(base + Math.floor(rand() * span)));
    }
    const o = db.prepare('INSERT INTO orders (customer_id, status, total_cents, created_at) VALUES (?,?,?,?)');
    const it = db.prepare('INSERT INTO order_items (order_id, product_id, quantity, unit_price_cents) VALUES (?,?,?,?)');
    const statuses = ['pending', 'paid', 'paid', 'shipped', 'shipped', 'shipped', 'cancelled'];
    for (let i = 1; i <= orders; i++) {
      const n = between(1, 5);
      const used = new Set();
      const lines = [];
      while (lines.length < n) {
        const pid = between(1, products);
        if (used.has(pid)) continue;
        used.add(pid);
        lines.push({ pid, qty: between(1, 4) });
      }
      const total = lines.reduce((s, l) => s + prices[l.pid - 1] * l.qty, 0);
      const { lastInsertRowid } = o.run(between(1, customers), pick(statuses), total,
        iso(base + Math.floor(rand() * span)));
      for (const l of lines) it.run(lastInsertRowid, l.pid, l.qty, prices[l.pid - 1]);
    }
  })();
}

module.exports = { seedDatabase };

if (require.main === module) {
  const config = loadConfig();
  if (process.argv.includes('--reset')) {
    for (const s of ['', '-wal', '-shm']) fs.rmSync(config.dbPath + s, { force: true });
  }
  // Seed without optimization indexes so loading is fast; the server applies the mode on start.
  const db = openDb(config.dbPath, { optimized: false });
  if (db.prepare('SELECT COUNT(*) AS n FROM users').get().n > 0) {
    console.error('Database already seeded. Re-run with --reset to wipe and reseed.');
    process.exit(1);
  }
  const num = (k, d) => Number(process.env[k] || d);
  const t0 = Date.now();
  seedDatabase(db, {
    customers: num('SEED_CUSTOMERS', 2000), products: num('SEED_PRODUCTS', 5000), orders: num('SEED_ORDERS', 50000),
    adminPassword: process.env.ARK_ADMIN_PASSWORD || 'admin-change-me',
    staffPassword: process.env.ARK_STAFF_PASSWORD || 'staff-change-me',
  });
  console.log(`Seeded ${config.dbPath} in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  console.log('Dev logins: admin / staff (set ARK_ADMIN_PASSWORD, ARK_STAFF_PASSWORD to override). Never use defaults outside local dev.');
  db.close();
}
