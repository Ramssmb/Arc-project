'use strict';
// Prints SQLite query plans for the hot queries in the CURRENT mode (set OPTIMIZED=1 for optimized).
const { loadConfig } = require('../src/config');
const { openDb } = require('../src/db');
const config = loadConfig();
const db = openDb(config.dbPath, { optimized: config.optimized });
console.log(`Mode: ${config.optimized ? 'optimized' : 'baseline'}\n`);
const queries = {
  'orders page (newest first)': ['SELECT o.id FROM orders o ORDER BY o.created_at DESC, o.id DESC LIMIT 50 OFFSET 0'],
  'orders by status': ["SELECT o.id FROM orders o WHERE o.status = 'paid' ORDER BY o.created_at DESC, o.id DESC LIMIT 50"],
  'orders by customer': ['SELECT o.id FROM orders o WHERE o.customer_id = 17 ORDER BY o.created_at DESC, o.id DESC LIMIT 50'],
  'items for one order': ['SELECT * FROM order_items WHERE order_id = 1234'],
  'top products': ['SELECT p.id, SUM(oi.quantity) u FROM order_items oi JOIN products p ON p.id = oi.product_id GROUP BY p.id ORDER BY u DESC LIMIT 10'],
};
for (const [name, [sql]] of Object.entries(queries)) {
  console.log(`## ${name}`);
  for (const r of db.prepare(`EXPLAIN QUERY PLAN ${sql}`).all()) console.log('  ', r.detail);
  console.log();
}
