'use strict';
// Runs the SAME benchmark against baseline then optimized mode on the SAME database file and
// writes a comparison to docs/results/. Usage: npm run ab   (needs a seeded DB: npm run seed)
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { run, toMarkdown } = require('./bench');

const PORT = 3101;
const base = `http://127.0.0.1:${PORT}`;
const durationS = Number(process.env.DURATION_S || 15);
const concurrency = Number(process.env.CONCURRENCY || 20);

async function withServer(optimized, fn) {
  const child = spawn('node', ['src/server.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, PORT: String(PORT), OPTIMIZED: optimized ? '1' : '0', LOG_LEVEL: 'silent', RATE_LIMIT_DISABLED: '1' },
    stdio: 'ignore',
  });
  try {
    for (let i = 0; i < 100; i++) {
      try { if ((await fetch(`${base}/api/health`)).ok) break; } catch { /* not up yet */ }
      await new Promise((r) => setTimeout(r, 100));
    }
    return await fn();
  } finally {
    child.kill('SIGTERM');
    await new Promise((r) => child.once('exit', r));
  }
}

(async () => {
  const baseline = await withServer(false, () => run({ base, durationS, concurrency }));
  const optimized = await withServer(true, () => run({ base, durationS, concurrency }));

  const out = [`# Baseline vs optimized (${new Date().toISOString()})`, '',
    'Same code, same DB file, same load script. Only OPTIMIZED=0/1 differs.',
    `Node ${process.version}, ${process.platform}/${process.arch}. Load generator and server share this machine.`, '',
    toMarkdown('Baseline (OPTIMIZED=0)', baseline), '', toMarkdown('Optimized (OPTIMIZED=1)', optimized), '',
    '### Change in p95 (negative = faster)', '', '| Scenario | Baseline p95 | Optimized p95 | Change |', '|---|---|---|---|'];
  baseline.rows.forEach((b, i) => {
    const o = optimized.rows[i];
    out.push(`| ${b.name} | ${b.p95.toFixed(1)} | ${o.p95.toFixed(1)} | ${(((o.p95 - b.p95) / b.p95) * 100).toFixed(0)}% |`);
  });
  const text = out.join('\n');
  const dir = path.join(__dirname, '..', '..', 'docs', 'results');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `ab-${new Date().toISOString().replace(/[:.]/g, '-')}.md`);
  fs.writeFileSync(file, text);
  console.log(text);
  console.log(`\nSaved: ${file}`);
})().catch((e) => { console.error(e); process.exit(1); });
