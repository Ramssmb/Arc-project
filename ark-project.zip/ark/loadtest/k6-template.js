// k6 version of the Node bench. Not executed when this project was built.
// BASE_URL=http://localhost:3000 ADMIN_PASSWORD=admin-change-me k6 run loadtest/k6-template.js
import http from 'k6/http';
import { check, sleep } from 'k6';
const BASE = __ENV.BASE_URL || 'http://localhost:3000';
export const options = {
  stages: [{ duration: '1m', target: 10 }, { duration: '2m', target: 50 }, { duration: '2m', target: 100 }, { duration: '1m', target: 0 }],
  thresholds: { http_req_failed: ['rate<0.01'], http_req_duration: ['p(95)<500'] }, // placeholders: set from real requirements
};
export function setup() {
  const r = http.post(`${BASE}/api/auth/login`, JSON.stringify({ username: 'admin', password: __ENV.ADMIN_PASSWORD || 'admin-change-me' }), { headers: { 'content-type': 'application/json' } });
  return { token: r.json('token') };
}
export default function (d) {
  const h = { headers: { authorization: `Bearer ${d.token}` } };
  const page = 1 + Math.floor(Math.random() * 50);
  check(http.get(`${BASE}/api/orders?page=${page}`, h), { 'orders 200': (x) => x.status === 200 });
  check(http.get(`${BASE}/api/stats`, h), { 'stats 200': (x) => x.status === 200 });
  sleep(1);
}
