# 03 LLD
## Modules
- `config.js` env → config (fails fast if `JWT_SECRET` missing in production)
- `db.js` schema + `applyMode()` (creates/drops optimization indexes so the toggle is reversible)
- `auth.js` JWT sign/verify, role guard, constant-ish-time login check
- `validate.js` integer/string/enum validators → 400 `BAD_REQUEST`
- `services/{orders,products,stats}.js` all SQL lives here; routes stay thin
- `routes.js` HTTP layer, validation, authz, cache invalidation
- `app.js` middleware, request id, access log (no query string, body or headers logged), error handler
## Data model
customers 1─* orders 1─* order_items *─1 products. `orders.total_cents` is denormalized at creation (price snapshot in `order_items.unit_price_cents`) so later price edits don't rewrite history.
## Patterns used (only where they solve something)
Service layer (isolates SQL for testing/equivalence checks); strategy-by-flag for naive vs optimized listing (temporary, for measurement. Delete the naive path once baseline is recorded in a real project).
## Known weak spots
`routes.js` mixes validation and orchestration; fine at this size, extract if endpoints grow. Money is integer cents, single currency (USD in UI).
