# 06 Security & reliability review
| Area | State |
|---|---|
| SQL injection | All queries parameterized; LIKE wildcards escaped; covered by a test |
| AuthN/AuthZ | JWT HS256 pinned (no `alg` confusion), role checks per route, tested 401/403 |
| Passwords | bcrypt; login timing equalized for unknown users; generic error message |
| Rate limiting | Login only (20/min/IP). **Gap:** no global limit; `/api` can be hammered |
| Headers / XSS | helmet defaults; React escapes output; no `dangerouslySetInnerHTML` |
| CSRF | Not applicable: Bearer header, no cookies |
| Token storage | sessionStorage (XSS-readable). Accepted trade-off; httpOnly cookie + CSRF protection is the stronger alternative |
| Secrets | `JWT_SECRET` required in production; **seed passwords are dev defaults, change them** |
| Logging | structured JSON; no bodies/headers/query strings logged |
| Dependencies | `npm audit --omit=dev`: 0 vulnerabilities at build time (re-run; this decays) |
| Reliability | `/health` checks DB; graceful shutdown; SQLite backups NOT automated (use `sqlite3 .backup`) |
## Gaps you should know about
No HTTPS in-app (needs a proxy), no token revocation/refresh, no audit log, no account lockout, no automated backups, no real penetration test.
