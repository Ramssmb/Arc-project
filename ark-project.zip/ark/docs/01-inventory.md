# 01 Inventory (this sample app; facts verified by running it)
| Item | Finding |
|---|---|
| Stack | Node 22, Express 4, better-sqlite3 (synchronous), React 18 + Vite 5 |
| Entry points | `backend/src/server.js` (app in `app.js`, routes in `routes.js`) |
| Database | SQLite file, WAL mode. Tables: users, customers, products, orders, order_items |
| Auth | JWT (HS256, 1h), bcrypt passwords, roles `admin` / `staff` |
| Third-party services | none |
| Tests | 14 (API, authz, validation, transactions, cache, naive-vs-optimized equivalence) |
| CI/CD | `.github/workflows/ci.yml` (tests + audit + frontend build) |
| Run locally | `npm install && npm run seed && npm start` |

## Endpoints
| Method | Path | Role | Notes |
|---|---|---|---|
| GET | /api/health | public | mode + DB ping |
| POST | /api/auth/login | public | rate limited 20/min/IP |
| GET | /api/metrics | admin | per-route counts/latency, cache stats |
| GET/POST/PUT | /api/products, /api/products/:id | read: any, write: admin | search/category/paging |
| GET | /api/orders, /api/orders/:id | any | filters: status, customer_id; paging |
| POST | /api/orders | staff, admin | transactional, stock check |
| PATCH | /api/orders/:id/status | staff, admin | pending→paid→shipped; cancel restocks |
| GET | /api/stats | any | revenue by status, top products, low stock |

## Business rules
Stock can't go negative; order creation is all-or-nothing; allowed transitions: pending→{paid,cancelled},
paid→{shipped,cancelled}; shipped and cancelled are final; cancelling returns stock.

## Known limitations
No customer CRUD endpoints, no refresh tokens, no password change, product search is substring `LIKE`.
