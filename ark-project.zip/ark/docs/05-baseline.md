# 05 Baseline & results
Raw outputs: `docs/results/ab-*.md` (two runs included: concurrency 20 and concurrency 1).
## Environment
Linux x64 sandbox, Node 22.22, SQLite 3.49, server and load generator on the same machine, seed: 2k customers / 5k products / 50k orders.
## Headline (isolated, concurrency 1, p95)
| Endpoint | Baseline | Optimized |
|---|---|---|
| GET /orders (page of 50) | 278 ms | 4.4 ms |
| GET /orders?customer_id | 111 ms | 3.4 ms |
| GET /stats | 153 ms | 2.5 ms |
## Under load (concurrency 20)
13 req/s → 416 req/s, overall p95 9.8 s → 88 ms.
**Do not quote the per-route numbers from the concurrency-20 run.** They are contaminated by head-of-line blocking (BN-004): fast endpoints look slow because they queue behind slow ones.
## Limitations
Single machine, shared CPU, one seed, one run per mode, baseline run first, synthetic data. The *direction and order of magnitude* of BN-001/002/003 are trustworthy because query plans corroborate them. Exact percentages are not. A 50k-order table is also small; real behavior will differ.
