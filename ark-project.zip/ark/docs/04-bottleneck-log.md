# 04 Bottleneck log (50k orders, 150k items, 5k products; isolated, concurrency=1)
| ID | Issue | Evidence | Measured p95 baseline → optimized | Status |
|---|---|---|---|---|
| BN-001 | `/orders` page: full scan + temp B-tree sort, then 2 queries per row (N+1) | `npm run explain`: `SCAN o` + `USE TEMP B-TREE FOR ORDER BY` → `SCAN … COVERING INDEX idx_orders_created` | 278 ms → 4.4 ms | VERIFIED |
| BN-002 | `/orders?customer_id=` scan + sort | plan: `SCAN o` → `SEARCH … idx_orders_customer_created` | 111 ms → 3.4 ms | VERIFIED |
| BN-003 | `/stats` recomputed per request (aggregate over 150k items) | plan: `SCAN oi` + temp B-trees → covering index; plus cache | 153 ms → 2.5 ms | VERIFIED (cache dominates; see note) |
| BN-004 | Event loop blocking: sync SQLite means ONE slow query stalls ALL requests | at concurrency 20 even `GET /products/:id` showed p50 ≈ 900 ms in baseline; throughput 13 → 416 req/s | | CONFIRMED (architectural; see ADR-0003) |
| BN-005 | `/products?search` substring `LIKE '%x%'` can't use a B-tree index | plan is a scan in both modes | 9.1 → 3.3 ms **not attributable**, see below | OPEN: needs FTS5 if catalog grows |
| BN-006 | Unbounded product list | code review; payload scales with catalog | n/a | FIXED behind flag (behavior change) |

**Rejected / not attributable:** `GET /products/:id` is a primary-key lookup whose code path is identical in both modes, yet showed 10 → 3.3 ms. That is measurement noise or run-order bias (baseline always ran first, cold page cache), not an improvement. Ignore it. A better harness would alternate A/B/A/B and repeat.
**Cache note:** BN-003's 2.5 ms is mostly cache hits. The *uncached* optimized cost is whatever the covering index buys; measure with `CACHE_TTL_MS=0` if you need that number.
