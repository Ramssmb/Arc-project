# 02 HLD
## Current architecture (one process, one file DB)
```
Browser (React SPA)
   │  HTTPS (terminate TLS at a reverse proxy in real deployments)
   ▼
Express app ── helmet ─ JSON parser ─ request-id/log ─ routes ─ services ─ better-sqlite3 ─ ark.db (WAL)
   │                                   │                              └─ in-process cache (stats)
   └─ serves frontend/dist             └─ JWT auth + role checks
```
- Auth boundary: every `/api` route except `/health` and `/auth/login` requires a Bearer token.
- Failure handling: uniform JSON errors with `requestId`; 5xx never leaks internals; graceful SIGTERM shutdown.

## What "optimized mode" changes (OPTIMIZED=1)
| Change | Problem solved | Trade-off / cost |
|---|---|---|
| 5 indexes (ADR-0001) | full scans + sorts on 50k orders | slower writes, extra disk; `ANALYZE` at startup |
| Batched order loading (N+1 → 3 queries) | 1+2×page-size queries per list request | slightly more complex code (guarded by equivalence test) |
| Stats cache, 30s TTL, invalidated on writes | repeated heavy aggregates | stale up to TTL on a *different* instance; per-process only |
| Product list paginated by default (20, max 100) | unbounded payloads | **behavior change** for clients that relied on "all products": needs approval |

## Capacity assumptions
UNKNOWN. This sample has no stated SLA. Numbers in `05-baseline.md` are relative, on one dev machine.

## Deliberately NOT done
Microservices, Redis, queues, Prometheus/Grafana: see ADR-0002. No measured need.
