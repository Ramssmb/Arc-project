# ADR-0003: Accept synchronous better-sqlite3 for now
Status: Accepted with known risk (BN-004). A slow query blocks the event loop. Fix the slow queries first (done), not the driver.
Revisit if: p99 under real traffic degrades, or write volume grows (SQLite = one writer). Then: Postgres + pooled async driver, or worker threads for heavy reads. Both are real migrations. Don't start them without a documented requirement.
