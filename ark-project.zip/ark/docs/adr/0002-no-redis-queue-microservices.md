# ADR-0002: No Redis, queue, or extra services
Status: Accepted. Evidence: after indexing, p95 is 2-5 ms per request on one process; the only cacheable hot spot is `/stats`, served by a 30s in-process cache.
Revisit if: multiple app instances need shared cache invalidation, or a long-running job (reports/imports) appears: none exist today.
