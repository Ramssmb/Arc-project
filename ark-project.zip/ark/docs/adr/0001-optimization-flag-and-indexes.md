# ADR-0001: Single codebase, `OPTIMIZED` flag, 5 indexes
Status: Accepted. Context: needed an honest before/after on identical code and data. Options: separate branches (drift risk), flag (chosen), do nothing.
Decision: flag toggles indexes (created/dropped idempotently), batched queries, caching, pagination default.
Consequences: reversible, A/B measurable. Cost: dead naive code stays until baseline is archived. Index write overhead not measured here (writes are rare in this workload; measure before adopting in a write-heavy system).
