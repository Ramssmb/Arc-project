# 07 AI-assisted workflow (Codex / Antigravity)
1 READ-ONLY: "Inspect this repo. Do NOT modify files. Summarize stack, entry points, data flow, DB access. Cite file paths."
2 VERIFY: "Which claims are you least sure of?" then check them yourself.
3 ISSUES: "List potential perf/security issues: file:line, why, how I could MEASURE it. No fixes."
4 IMPLEMENT ONE approved item: "Implement only BN-xxx, add tests, minimal files, explain the diff."
5 ATTACK: "Argue against your own change. What breaks? What's untested?"
Then run tests, re-run `npm run ab`, record in docs, commit. Never give the agent production credentials.
