import { useCallback, useEffect, useState } from 'react';
import { api, getToken, setToken, money } from './api.js';

function useFetch(path, deps) {
  const [state, set] = useState({ loading: true, error: null, data: null });
  useEffect(() => {
    const ctl = new AbortController();
    set((s) => ({ ...s, loading: true, error: null }));
    api(path, { signal: ctl.signal })
      .then((data) => set({ loading: false, error: null, data }))
      .catch((e) => { if (e.name !== 'AbortError') set({ loading: false, error: e.message, data: null }); });
    return () => ctl.abort(); // prevents stale responses overwriting newer ones
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return state;
}

function Status({ s }) {
  if (s.loading) return <p className="note" role="status">Loading…</p>;
  if (s.error) return <p className="note error" role="alert">{s.error}</p>;
  return null;
}

function Pager({ page, limit, total, onPage }) {
  const pages = Math.max(1, Math.ceil(total / limit));
  return (
    <div className="pager">
      <button disabled={page <= 1} onClick={() => onPage(page - 1)}>Previous</button>
      <span>Page {page} of {pages} ({total.toLocaleString()} total)</span>
      <button disabled={page >= pages} onClick={() => onPage(page + 1)}>Next</button>
    </div>
  );
}

function Login({ onDone }) {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault();
    setBusy(true); setErr('');
    try {
      const r = await api('/api/auth/login', { method: 'POST', body: { username: u, password: p } });
      setToken(r.token); onDone(r.user);
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  }
  return (
    <main className="login">
      <h1>ARK orders</h1>
      <form onSubmit={submit}>
        <label>Username<input value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" required /></label>
        <label>Password<input type="password" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" required /></label>
        {err && <p className="note error" role="alert">{err}</p>}
        <button className="primary" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </main>
  );
}

function Orders() {
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('');
  const limit = 25;
  const q = `/api/orders?page=${page}&limit=${limit}${status ? `&status=${status}` : ''}`;
  const s = useFetch(q, [q]);
  return (
    <section>
      <div className="toolbar">
        <label>Status
          <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
            <option value="">All</option>
            {['pending', 'paid', 'shipped', 'cancelled'].map((x) => <option key={x}>{x}</option>)}
          </select>
        </label>
      </div>
      <Status s={s} />
      {s.data && (
        <>
          <div className="scroll">
            <table>
              <thead><tr><th>Order</th><th>Customer</th><th>Status</th><th>Items</th><th className="num">Total</th><th>Placed</th></tr></thead>
              <tbody>
                {s.data.data.map((o) => (
                  <tr key={o.id}>
                    <td className="num">#{o.id}</td>
                    <td>{o.customer.name}</td>
                    <td><span className={`pill ${o.status}`}>{o.status}</span></td>
                    <td>{o.items.length}</td>
                    <td className="num">{money(o.total_cents)}</td>
                    <td>{new Date(o.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {s.data.data.length === 0 && <p className="note">No orders match this filter.</p>}
          <Pager page={page} limit={limit} total={s.data.total} onPage={setPage} />
        </>
      )}
    </section>
  );
}

function Products() {
  const [page, setPage] = useState(1);
  const [input, setInput] = useState('');
  const [search, setSearch] = useState('');
  const limit = 25;
  useEffect(() => { const t = setTimeout(() => { setSearch(input.trim()); setPage(1); }, 300); return () => clearTimeout(t); }, [input]);
  const q = `/api/products?page=${page}&limit=${limit}${search ? `&search=${encodeURIComponent(search)}` : ''}`;
  const s = useFetch(q, [q]);
  return (
    <section>
      <div className="toolbar">
        <label>Search products<input value={input} onChange={(e) => setInput(e.target.value)} placeholder="e.g. Lantern" /></label>
      </div>
      <Status s={s} />
      {s.data && (
        <>
          <div className="scroll">
            <table>
              <thead><tr><th>SKU</th><th>Name</th><th>Category</th><th className="num">Price</th><th className="num">Stock</th></tr></thead>
              <tbody>
                {s.data.data.map((p) => (
                  <tr key={p.id}>
                    <td>{p.sku}</td><td>{p.name}</td><td>{p.category}</td>
                    <td className="num">{money(p.price_cents)}</td>
                    <td className={`num ${p.stock < 10 ? 'low' : ''}`}>{p.stock}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {s.data.data.length === 0 && <p className="note">No products match “{search}”.</p>}
          <Pager page={page} limit={limit} total={s.data.total} onPage={setPage} />
        </>
      )}
    </section>
  );
}

function Stats() {
  const s = useFetch('/api/stats', []);
  return (
    <section>
      <Status s={s} />
      {s.data && (
        <div className="stats">
          <div>
            <h2>Revenue by status</h2>
            <table>
              <thead><tr><th>Status</th><th className="num">Orders</th><th className="num">Revenue</th></tr></thead>
              <tbody>{s.data.byStatus.map((r) => (
                <tr key={r.status}><td><span className={`pill ${r.status}`}>{r.status}</span></td>
                  <td className="num">{r.orders.toLocaleString()}</td><td className="num">{money(r.revenue_cents)}</td></tr>))}
              </tbody>
            </table>
          </div>
          <div>
            <h2>Top 10 products by units sold</h2>
            <table>
              <thead><tr><th>Product</th><th className="num">Units</th></tr></thead>
              <tbody>{s.data.topProducts.map((r) => <tr key={r.id}><td>{r.name}</td><td className="num">{r.units.toLocaleString()}</td></tr>)}</tbody>
            </table>
            <p className="note">{s.data.lowStockProducts} products have fewer than 10 units in stock.</p>
          </div>
        </div>
      )}
    </section>
  );
}

export default function App() {
  const [user, setUser] = useState(() => (getToken() ? { restored: true } : null));
  const [tab, setTab] = useState('orders');
  const [mode, setMode] = useState('');
  const logout = useCallback(() => { setToken(null); setUser(null); }, []);
  useEffect(() => { window.addEventListener('ark:logout', logout); return () => window.removeEventListener('ark:logout', logout); }, [logout]);
  useEffect(() => { api('/api/health').then((h) => setMode(h.mode)).catch(() => setMode('unreachable')); }, []);
  if (!user) return <Login onDone={setUser} />;
  return (
    <div className="shell">
      <header>
        <h1>ARK orders</h1>
        <nav aria-label="Sections">
          {['orders', 'products', 'stats'].map((t) => (
            <button key={t} className={tab === t ? 'active' : ''} aria-current={tab === t} onClick={() => setTab(t)}>
              {t[0].toUpperCase() + t.slice(1)}
            </button>
          ))}
        </nav>
        <div className="right"><span className="mode" title="Server mode (OPTIMIZED env)">{mode}</span><button onClick={logout}>Sign out</button></div>
      </header>
      <main>{tab === 'orders' ? <Orders /> : tab === 'products' ? <Products /> : <Stats />}</main>
    </div>
  );
}
