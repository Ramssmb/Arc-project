// Token lives in sessionStorage: survives reload, cleared when the tab closes.
// Trade-off: readable by any XSS. React escapes output by default; never use dangerouslySetInnerHTML here.
const KEY = 'ark.token';
export const getToken = () => sessionStorage.getItem(KEY);
export const setToken = (t) => (t ? sessionStorage.setItem(KEY, t) : sessionStorage.removeItem(KEY));

export async function api(path, { method = 'GET', body, signal } = {}) {
  const token = getToken();
  const res = await fetch(path, {
    method,
    signal,
    headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && token) { setToken(null); window.dispatchEvent(new Event('ark:logout')); }
    const e = new Error(data?.error?.message || `Request failed (${res.status})`);
    e.status = res.status;
    throw e;
  }
  return data;
}

export const money = (cents) => (cents / 100).toLocaleString(undefined, { style: 'currency', currency: 'USD' });
