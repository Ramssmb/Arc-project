#!/usr/bin/env bash
# Usage: ./audit_repo.sh /path/to/ark
R="${1:-.}"; cd "$R" || exit 1
EX="--exclude-dir=node_modules --exclude-dir=.git --exclude-dir=dist --exclude-dir=build"
echo "## Manifests / stack signals"
find . -maxdepth 3 \( -name package.json -o -name requirements.txt -o -name pyproject.toml -o -name pom.xml -o -name build.gradle -o -name go.mod -o -name Gemfile -o -name composer.json -o -name '*.csproj' -o -name Dockerfile -o -name 'docker-compose*.yml' \) -not -path '*/node_modules/*'
echo; echo "## Files by extension (top 10)"
git ls-files 2>/dev/null | sed -n 's/.*\.//p' | sort | uniq -c | sort -rn | head
echo; echo "## Env / config files (never commit secrets)"
find . -maxdepth 3 \( -name '.env*' -o -name 'config*.y*ml' -o -name 'settings*.py' \) -not -path '*/node_modules/*'
echo; echo "## Tests present?"
find . \( -iname '*test*' -o -iname '*spec*' \) -not -path '*/node_modules/*' -not -path './.git/*' | head -20
echo; echo "## CI"
ls .github/workflows 2>/dev/null || echo "none found"
echo; echo "## Route/endpoint hints"
grep -RInE "(app|router)\.(get|post|put|delete|patch)\(|@(Get|Post|Put|Delete|Patch)Mapping|@app\.route|@router\.|path\(" . $EX -s 2>/dev/null | head -60
echo; echo "## Likely DB usage"
grep -RIlE "mongoose|sequelize|prisma|typeorm|sqlalchemy|psycopg|mysql|sqlite|redis|knex|gorm|hibernate" . $EX -s 2>/dev/null | head -20
echo; echo "## Hardcoded-secret smell (review manually)"
grep -RInE "(password|secret|api[_-]?key|token)\s*[:=]\s*['\"][^'\"]{6,}" . $EX -s 2>/dev/null | grep -vE "\.lock|test" | head -20
echo; echo "## TODO/FIXME count"; grep -RInE "TODO|FIXME|HACK" . $EX -s 2>/dev/null | wc -l
