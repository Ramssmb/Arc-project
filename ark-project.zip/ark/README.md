# ARK (sample reference implementation)

**Read this first.** Your brief describes ARK as an *existing* application. I was never given that repo, so this is a
**self-built stand-in**: an orders/inventory app (Node + Express + SQLite + React) with realistic, *deliberately
naive* hot spots, plus everything the brief asks you to do around it (HLD/LLD, baseline, optimization, tests, load
test, security review, CI, Docker). Use it to practice the workflow or as a template. **Do not present it to your
mentor as the real ARK.** If you get the real repo, run `scripts/audit_repo.sh` against it and reuse the docs/ templates.

## Quick start
```bash
cd backend && npm install && npm run seed          # ~2k customers, 5k products, 50k orders (<2s)
npm test                                           # 14 tests, all offline
npm start                                          # baseline mode on :3000 (API only)
OPTIMIZED=1 npm start                              # optimized mode
cd ../frontend && npm install && npm run build     # then the backend serves the UI at http://localhost:3000
# dev UI with hot reload: (backend running) cd frontend && npm run dev  -> http://localhost:5173
```
Dev logins after seeding: `admin` / `admin-change-me`, `staff` / `staff-change-me`
(override with `ARK_ADMIN_PASSWORD`, `ARK_STAFF_PASSWORD` before seeding). **Local dev only.**

## Measure it yourself
```bash
cd backend
npm run explain                    # query plans, baseline   (OPTIMIZED=1 npm run explain for optimized)
CONCURRENCY=1  DURATION_S=12 npm run ab    # isolated per-endpoint latency, baseline vs optimized
CONCURRENCY=20 DURATION_S=10 npm run ab    # under load (see caveat in docs/05-baseline.md)
```
Results are written to `docs/results/`. Same code, same DB file; only `OPTIMIZED=0/1` differs.

## Layout
- `backend/` API, services, seed, explain/bench/ab scripts, tests
- `frontend/` React + Vite UI (orders, products, stats)
- `docs/` inventory, HLD, LLD, bottleneck log, baseline, ADRs, security, scalability, OpenAPI, results
- `loadtest/k6-template.js` k6 version of the scenarios (k6 not run here)
- `Dockerfile`, `docker-compose.yml`, `.github/workflows/ci.yml` (**not executed in the environment that built this**)
